ROYAL COURIER AUDIT / FICTIONAL REALM
The ledger format is documented in cipher/PROCEDURE.txt. Do not trust filenames or
the SEQUENCE field alone: an authentic dispatch must have a listed seal, point to the
previous authentic seal, and obey route/weather travel constraints. After recovering
the four-stop route, concatenate the first letter of each stop to form the key.
Decrypt the columnar-transposition ciphertext. Its plaintext is the CORE; append the
personal token from Cipherground and submit CTF{CORE:TOKEN}.